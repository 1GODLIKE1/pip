.. threaded documentation master file, created by
   sphinx-quickstart on Sun Oct 30 13:40:52 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

.. include:: ../../README.rst

Contents:

.. toctree::
    :maxdepth: 2

    threadpooled
    threaded
    asynciotask

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
